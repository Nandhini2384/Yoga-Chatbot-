from flask import Flask, render_template, request, redirect, session, flash, jsonify
from flask_mysqldb import MySQL
import json
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MySQL Config
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'admin'
app.config['MYSQL_DB'] = 'your_database'

mysql = MySQL(app)
# Home Route


@app.route('/')
def home():
   return render_template('home.html')  # Ensure the file has .html extension
 # Show the home page instead of redirecting



# Signup Route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role', 'user')

        if not username or not password:
            flash('All fields are required!')
            return redirect('/signup')

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s", (username,))
        existing_user = cur.fetchone()

        if existing_user:
            flash('Username already exists!')
            return redirect('/signup')

        cur.execute("INSERT INTO users (username, password, role) VALUES (%s, %s, %s)", (username, password, role))
        mysql.connection.commit()
        cur.close()
        flash('Signup successful! Please login.')
        return redirect('/login')

    return render_template('signup.html')


# Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            flash('All fields are required!')
            return redirect('/login')

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
        user = cur.fetchone()
        cur.close()

        if user:
            session['username'] = user[1]
            session['role'] = user[3]
            if session['role'] == 'admin':
                return redirect('/admin')
            else:
                return redirect('/chatbot')
        else:
            flash('Invalid username or password!')
            return redirect('/login')

    return render_template('login.html')


# Logout Route
@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.')
    return redirect('/login')


# Admin Page
@app.route('/admin')
def admin_page():
    if 'username' in session and session['role'] == 'admin':
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, username, role FROM users")
        users = cur.fetchall()
        cur.close()
        return render_template('admin_home.html', users=users)
    flash('Access denied!')
    return redirect('/login')


QUESTIONS_FILE = 'questions.json'
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Ensure upload directory exists


# Load questions from JSON file
def load_questions():
    if os.path.exists(QUESTIONS_FILE):
        with open(QUESTIONS_FILE, 'r') as file:
            return json.load(file)
    return []


# Save questions to JSON file
def save_questions(questions):
    with open(QUESTIONS_FILE, 'w') as file:
        json.dump(questions, file, indent=4)


# Route to render Add Questions Page
@app.route('/add_questions', methods=['GET'])
def add_questions_page():
    if 'username' in session and session['role'] == 'admin':
        return render_template('add_questions.html')
    flash('Access denied!')
    return redirect('/login')

UPLOAD_FOLDER = os.path.join("static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Ensure the folder exists

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

from flask import send_from_directory

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory("uploads", filename)


# Temporary in-memory storage
questions = []

@app.route('/api/add_question', methods=['POST'])
def add_question():
    try:
        question = request.form.get("question")
        keywords = request.form.get("keywords")
        image = request.files.get("image")

        if not question or not keywords:
            return jsonify({"error": "Missing question or keywords"}), 400

        image_filename = None
        if image:
            image_filename = os.path.join("uploads", image.filename)
            image.save(image_filename)  # Save image

        # Add question to list (or database)
        new_question = {
            "question": question,
            "keywords": keywords.split(","),  # Convert string to list
            "image": image_filename if image else None
        }
        questions.append(new_question)

        print("New Question Added:", new_question)  # Debugging log

        return jsonify({"message": "Question added successfully!"}), 200

    except Exception as e:
        print("Error in add_question:", str(e))  # Debugging log
        return jsonify({"error": "Internal Server Error"}), 500

@app.route('/api/get_questions', methods=['GET'])
def get_questions():
    return jsonify({"questions": questions}), 200

# API Route to Delete a Question by ID
@app.route('/api/delete_question/<int:question_id>', methods=['DELETE'])
def delete_question(question_id):
    questions = load_questions()
    updated_questions = [q for q in questions if q['id'] != question_id]

    if len(updated_questions) == len(questions):  # No ID match found
        return jsonify({'message': 'Question not found!'}), 404

    save_questions(updated_questions)
    return jsonify({'message': 'Question deleted successfully!'}), 200


# API Route to Update a Question by ID
@app.route('/api/update_question/<int:question_id>', methods=['PUT'])
def update_question(question_id):
    try:
        questions = load_questions()
        data = request.get_json()

        for question in questions:
            if question['id'] == question_id:
                question['keywords'] = data.get('keywords', question['keywords'])
                question['description'] = data.get('description', question['description'])
                question['instructions'] = data.get('instructions', question['instructions'])
                break
        else:
            return jsonify({'message': 'Question not found!'}), 404

        save_questions(questions)
        return jsonify({'message': 'Question updated successfully!'}), 200

    except Exception as e:
        print("Error:", e)
        return jsonify({'message': f'Error: {str(e)}'}), 500


# API Route to Upload Image
@app.route('/api/upload_image', methods=['POST'])
def upload_image():
    try:
        if 'image' not in request.files:
            return jsonify({'message': 'No image uploaded!'}), 400

        image = request.files['image']
        if image.filename == '':
            return jsonify({'message': 'No selected file!'}), 400

        image_path = os.path.join(UPLOAD_FOLDER, image.filename)
        image.save(image_path)

        return jsonify({'message': 'Image uploaded successfully!', 'image_url': image_path}), 200

    except Exception as e:
        print("Error:", e)
        return jsonify({'message': 'Server error', 'error': str(e)}), 500



@app.route('/chatbot')
def chatbot():
    if 'username' in session and session['role'] == 'user':
        return render_template('chatbot.html', username=session['username'])
    flash('Access denied!')
    return redirect('/login')

def load_questions():
    with open("filename.json", "r", encoding="utf-8") as file:
        return json.load(file)

@app.route('/keyword_search', methods=['GET', 'POST'])
def keyword_search():
    question = None
    searched = False

    if 'username' in session and session['role'] == 'user':
        if request.method == 'POST':
            keyword = request.form.get('keyword', '').strip().lower()
            questions = load_questions()

            for q in questions:
                keywords_list = q.get('keywords', [])  # Ensure keywords exist
                if isinstance(keywords_list, list):  # If stored as a list
                    if any(keyword in k.lower() for k in keywords_list):
                        question = q
                        break
                elif isinstance(keywords_list, str):  # If stored as a string
                    if keyword in keywords_list.lower():
                        question = q
                        break

            searched = True

        return render_template('search_results.html', username=session['username'], question=question, searched=searched)

    flash('Access denied!')
    return redirect('/login')

@app.route('/chatbot_api', methods=['GET', 'POST'])
def chatbot_api():
    question = None
    searched = False

    if request.method == 'POST':
        keyword = request.form.get('keyword').lower()
        searched = True

        # Search through the JSON data
        for q in questions:
            if keyword in q['keywords'].lower():
                question = q
                break

    return render_template('chatbot.html', question=question, searched=searched)


@app.route('/view_logs')
def view_logs():
    if 'username' in session and session['role'] == 'admin':
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, username, role FROM users")  # Fetch user details
        users = cur.fetchall()  # Get all users
        cur.close()
        return render_template('view_logs.html', users=users)  # Pass data to template
    else:
        return "Access Denied"


    

FILE_NAME = "yoga_masters.txt"

# Function to load yoga masters from the text file
def load_yoga_masters():
    try:
        with open(FILE_NAME, "r") as file:
            return [line.strip().split(",") for line in file.readlines()]
    except FileNotFoundError:
        return []

# Function to save yoga masters to the text file
def save_yoga_masters(yoga_masters):
    with open(FILE_NAME, "w") as file:
        for master in yoga_masters:
            file.write(",".join(master) + "\n")

@app.route('/manage_yoga_masters')
def manage_yoga_masters():
    yoga_masters = load_yoga_masters()
    return render_template('manage_yoga_masters.html', yoga_masters=yoga_masters)

@app.route('/add_yoga_master', methods=['POST'])
def add_yoga_master():
    name = request.form['name']
    expertise = request.form['expertise']
    
    yoga_masters = load_yoga_masters()
    new_id = len(yoga_masters) + 1
    yoga_masters.append([str(new_id), name, expertise])  # Convert ID to string
    
    save_yoga_masters(yoga_masters)
    return redirect('/manage_yoga_masters')

@app.route('/delete_yoga_master/<int:id>')
def delete_yoga_master(id):
    yoga_masters = load_yoga_masters()
    yoga_masters = [m for m in yoga_masters if int(m[0]) != id]  # Remove matching ID
    
    save_yoga_masters(yoga_masters)
    return redirect('/manage_yoga_masters')


if __name__ == '__main__':
    app.run(debug=True)
